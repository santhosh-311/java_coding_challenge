package org.hexaware.dao;

import org.hexaware.entity.*;
import org.hexaware.util.DBConnUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PetInfoDAOImpl implements PetInfoDAO {
    private static String SELECT_AVAILABLE_PETS_QUERY = "select * from pets where available_for_adoption = 1";
    private static String INSERT_PET_QUERY = "insert into pets (name, age, breed, available_for_adoption) true (?, ?, ?, TRUE)";

    @Override
    public void addPet(Pet pet) {
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(INSERT_PET_QUERY)) {

            pstmt.setString(1, pet.getName());
            pstmt.setInt(2, pet.getAge());
            pstmt.setString(3, pet.getBreed());

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 1) {
                System.out.println("Pet added successfully: " + pet);
            }

        } catch (SQLException e) {
            System.out.println("Database error while adding pet: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An error occurred while adding pet: " + e.getMessage());
        }
    }

    @Override
    public List<Pet> listAvailablePets() {
        List<Pet> pets = new ArrayList<>();

        try (Connection conn = DBConnUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(SELECT_AVAILABLE_PETS_QUERY)) {

            while (rs.next()) {
                String name = rs.getString("name");
                int age = rs.getInt("age");
                String breed = rs.getString("breed");

                // Create a new Pet object and add it to the list
                pets.add(new Pet(name, age, breed));
            }

        } catch (SQLException e) {
            System.out.println("Database error while listing pets: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An error occurred while listing pets: " + e.getMessage());
        }

        return pets;
    }
}
