package org.hexaware.dao;
import org.hexaware.entity.*;
import org.hexaware.util.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdoptionEventDAOImpl implements AdoptionEventDAO {
    private static final String INSERT_EVENT_QUERY = "INSERT INTO adoption_events (event_name, event_date, location) VALUES (?, ?, ?)";
    private static final String SELECT_UPCOMING_EVENTS_QUERY = "SELECT * FROM adoption_events WHERE event_date > NOW()";
    private static final String INSERT_PARTICIPANT_QUERY = "INSERT INTO participants (participant_name, participant_type, event_id) VALUES (?, ?, ?)";

    @Override
    public void addEvent(AdoptionEvent event) {
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(INSERT_EVENT_QUERY)) {

            pstmt.setString(1, event.getEventName());
            pstmt.setString(2, event.getEventDate());
            pstmt.setString(3, event.getLocation());

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Event added successfully: " + event);
            }

        } catch (SQLException e) {
            System.out.println("Database error while adding event: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An error occurred while adding event: " + e.getMessage());
        }
    }

    @Override
    public List<AdoptionEvent> listUpcomingEvents() {
        List<AdoptionEvent> events = new ArrayList<>();

        try (Connection conn = DBConnUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(SELECT_UPCOMING_EVENTS_QUERY)) {

            while (rs.next()) {
                int eventId = rs.getInt("event_id");
                String eventName = rs.getString("event_name");
                String eventDate = rs.getString("event_date");
                String location = rs.getString("location");

                events.add(new AdoptionEvent(eventId, eventName, eventDate, location));
            }

        } catch (SQLException e) {
            System.out.println("Database error while listing events: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An error occurred while listing events: " + e.getMessage());
        }

        return events;
    }

    @Override
    public void registerParticipant(Participants participant, int eventId) {
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(INSERT_PARTICIPANT_QUERY)) {

            pstmt.setString(1, participant.getParticipantName());
            pstmt.setString(2, participant.getParticipantType());
            pstmt.setInt(3, eventId);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Participant registered successfully for event ID " + eventId);
            }

        } catch (SQLException e) {
            System.out.println("Database error while registering participant: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An error occurred while registering participant: " + e.getMessage());
        }
    }
}
