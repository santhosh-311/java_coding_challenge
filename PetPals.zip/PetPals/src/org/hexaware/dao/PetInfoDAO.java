package org.hexaware.dao;

import org.hexaware.entity.*;
import java.util.List;

public interface PetInfoDAO {
    // Method to add a pet
    public abstract void addPet(Pet pet);

    // Method to list available pets
    public abstract List<Pet> listAvailablePets();
}
