package org.hexaware.dao;
import org.hexaware.entity.Donation;
import org.hexaware.util.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.hexaware.entity.ItemDonation;

public class DonationDAOImpl implements DonationDAO {
    private static final String INSERT_CASH_DONATION_QUERY = "INSERT INTO donations (donor_name, donation_amount) VALUES (?, ?)";
    private static final String INSERT_ITEM_DONATION_QUERY = "INSERT INTO donations (donor_name, donation_amount, item_type) VALUES (?, ?, ?)";
    @Override
    public void recordDonation(Donation donation) {
        if (donation instanceof ItemDonation) {
            recordItemDonation((ItemDonation) donation);
        } else {
            recordCashDonation(donation);
        }
    }
    // Method to record cash donations
    private void recordCashDonation(Donation donation) {
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(INSERT_CASH_DONATION_QUERY)) {

            pstmt.setString(1, donation.getDonorName());
            pstmt.setDouble(2, donation.getAmount());

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Cash donation recorded successfully: " + donation);
            }
        } catch (SQLException e) {
            System.out.println("Database error while recording cash donation: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An error occurred while recording cash donation: " + e.getMessage());
        }
    }
    // Method to record item donations
    private void recordItemDonation(ItemDonation itemDonation) {
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(INSERT_ITEM_DONATION_QUERY)) {

            pstmt.setString(1, itemDonation.getDonorName());
            pstmt.setDouble(2, itemDonation.getAmount());
            pstmt.setString(3, itemDonation.getItemType());

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Item donation recorded successfully: " + itemDonation);
            }
        } catch (SQLException e) {
            System.out.println("Database error while recording item donation: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An error occurred while recording item donation: " + e.getMessage());
        }
    }
}

