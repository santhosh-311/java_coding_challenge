package org.hexaware.dao;

import org.hexaware.entity.*;

import java.util.List;

public interface AdoptionEventDAO {
    // Method to add an event
    public abstract void addEvent(AdoptionEvent event);

    // Method to list upcoming events
    public abstract List<AdoptionEvent> listUpcomingEvents();

    // Method to register a participant for an event
    public abstract void registerParticipant(Participants participant, int eventId);
}
