package org.hexaware.dao;

import org.hexaware.entity.*;

public interface DonationDAO {
    // Method to record a donation
    public abstract void recordDonation(Donation donation);
}
