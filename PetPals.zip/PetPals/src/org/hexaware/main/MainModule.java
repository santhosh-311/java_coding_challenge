package org.hexaware.main;

import org.hexaware.dao.DonationDAOImpl;
import org.hexaware.dao.PetInfoDAOImpl;
import org.hexaware.dao.AdoptionEventDAOImpl;
import org.hexaware.entity.AdoptionEvent;
import org.hexaware.entity.CashDonation;
import org.hexaware.entity.ItemDonation;
import org.hexaware.entity.Participants;
import org.hexaware.entity.Pet;

import java.util.List;
import java.util.Scanner;

public class MainModule {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PetInfoDAOImpl petDAO = new PetInfoDAOImpl();
        DonationDAOImpl donationDAO = new DonationDAOImpl();
        AdoptionEventDAOImpl eventDAO = new AdoptionEventDAOImpl();

        while (true) {
            System.out.println("\n--- PetPals Management Menu ---");
            System.out.println("1. Add Pet");
            System.out.println("2. List Available Pets");
            System.out.println("3. Record Cash Donation");
            System.out.println("4. Record Item Donation");
            System.out.println("5. Add Adoption Event");
            System.out.println("6. List Upcoming Events");
            System.out.println("7. Register Participant");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    // Add Pet
                    System.out.print("Enter Pet Name: ");
                    String name = scanner.nextLine();

                    System.out.print("Enter Pet Age: ");
                    int age = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    System.out.print("Enter Pet Breed: ");
                    String breed = scanner.nextLine();

                    Pet newPet = new Pet(name, age, breed);
                    petDAO.addPet(newPet);
                    break;

                case 2:
                    // List Available Pets
                    List<Pet> availablePets = petDAO.listAvailablePets();
                    System.out.println("Available Pets:");
                    for (Pet pet : availablePets) {
                        System.out.println(pet);
                    }
                    break;

                case 3:
                    // Record Cash Donation
                    System.out.print("Enter Donor Name: ");
                    String donorName = scanner.nextLine();

                    System.out.print("Enter Donation Amount: ");
                    double cashDonationAmount = scanner.nextDouble();

                    CashDonation cashDonation = new CashDonation(donorName, cashDonationAmount);
                    donationDAO.recordDonation(cashDonation);
                    break;

                case 4:
                    // Record Item Donation
                    System.out.print("Enter Donor Name: ");
                    String itemDonorName = scanner.nextLine();

                    System.out.print("Enter Donation Amount: ");
                    double itemDonationAmount = scanner.nextDouble();

                    System.out.print("Enter Item Type: ");
                    scanner.nextLine(); // Consume newline
                    String itemType = scanner.nextLine();

                    ItemDonation itemDonation = new ItemDonation(itemDonorName, itemDonationAmount, itemType);
                    donationDAO.recordDonation(itemDonation);
                    break;

                case 5:
                    // Add Adoption Event
                    System.out.print("Enter Event Name: ");
                    String eventName = scanner.nextLine();

                    System.out.print("Enter Event Date (yyyy-MM-dd): ");
                    String dateInput = scanner.nextLine();

                    System.out.print("Enter Event Location: ");
                    String location = scanner.nextLine();

                    AdoptionEvent newEvent = new AdoptionEvent(0, eventName, dateInput, location);
                    eventDAO.addEvent(newEvent);
                    break;

                case 6:
                    // List Upcoming Events
                    List<AdoptionEvent> upcomingEvents = eventDAO.listUpcomingEvents();
                    System.out.println("Upcoming Adoption Events:");
                    for (AdoptionEvent event : upcomingEvents) {
                        System.out.println(event);
                    }
                    break;

                case 7:
                    // Register Participant
                    System.out.print("Enter Participant Name: ");
                    String participantName = scanner.nextLine();

                    System.out.print("Enter Participant Type: ");
                    String participantType = scanner.nextLine();

                    System.out.print("Enter Event ID to register: ");
                    int eventId = scanner.nextInt();
                    Participants participant = new Participants(participantName, participantType);
                    eventDAO.registerParticipant(participant, eventId);
                    break;

                case 8:
                    // Exit
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
