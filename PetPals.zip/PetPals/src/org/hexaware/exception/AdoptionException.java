package org.hexaware.exception;

// Custom Exception Class
public class AdoptionException extends Exception {
    public AdoptionException(String message) {
        super(message);
    }
}
