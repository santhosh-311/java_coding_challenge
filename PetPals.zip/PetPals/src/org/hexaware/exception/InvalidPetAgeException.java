package org.hexaware.exception;

import org.hexaware.entity.*;

// Custom Exception Class
public class InvalidPetAgeException extends Exception {
    public InvalidPetAgeException(String message) {
        super(message);
    }
}
