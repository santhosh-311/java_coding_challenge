package org.hexaware.exception;

import org.hexaware.entity.Pet;

public class NullReferenceException {

    // Handle Pet Null Reference Exception
    public static void handleNullReferenceException(Pet pet) {
        try {
            if (pet.getName() == null || pet.getBreed() == null) {
                throw new Exception("Information is missing for a pet.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            System.out.println("Missing information for a pet: Name: " + (pet.getName() == null ? "Unknown" : pet.getName())
                    + ", Age: " + (pet.getAge()<1 ? 1 : pet.getAge())
                    + ", Breed: " + (pet.getBreed() == null ? "Unknown" : pet.getBreed()));
        }
    }

    // Handle Pet Age Exception
    public static void handlePetAgeException(int age) {
        try {
            if (age < 1) {
                throw new Exception("Age must be a positive number.");
            }
        } catch (Exception e) {
            System.out.println("Caught Exception: " + e.getMessage());
        }
    }
}
