package org.hexaware.entity;

import java.util.ArrayList;
import java.util.List;

public class AdoptionEvent {
    private int eventId;                  
    private String eventName;             
    private String eventDate;
    private String location;              
    private List<IAdoptable> participants;

    // Constructor
    public AdoptionEvent(int eventId, String eventName, String eventDate, String location) {
        this.eventId = eventId;
        this.eventName = eventName;
        this.eventDate = eventDate;
        this.location = location;
        this.participants = new ArrayList<>(); // Initialize participants list
    }

    // Getters and Setters
    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventDate() {
        return eventDate;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public List<IAdoptable> getParticipants() {
        return participants;
    }

    // Method to register a participant for the event
    public void registerParticipant(Participants participant) {
        participants.add(participant);
        System.out.println("Participant " + participant.getParticipantName() + " registered for the event: " + eventName);
    }

    @Override
    public String toString() {
        return "AdoptionEvent [ID=" + eventId + ", Name=" + eventName + ", Date=" + eventDate + ", Location=" + location + 
               ", Participants=" + participants.size() + "]";
    }
}


//AdoptionEvent Class:
//Attributes:
//• Participants (List of IAdoptable): A list of participants (shelters and adopters) in the adoption
//event.
//Methods:
//• HostEvent(): Hosts the adoption event.
//• RegisterParticipant(IAdoptable participant): Registers a participant for the event.
