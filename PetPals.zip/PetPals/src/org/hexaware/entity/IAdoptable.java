package org.hexaware.entity;

public abstract class IAdoptable {
	abstract public void adopt();
}
