package org.hexaware.entity;

import java.time.LocalDateTime;

public class CashDonation extends Donation {
    private LocalDateTime donationDate;  // The date when the cash donation was made

    // Constructor to initialize donorName, amount, and donationDate
    public CashDonation(String donorName, double amount) {
        super(donorName, amount);
        this.donationDate = LocalDateTime.now(); // Automatically set the donation date to now
    }

    public LocalDateTime getDonationDate() {
        return donationDate;
    }

    @Override
    public void recordDonation() {
        // Logic to record the cash donation if needed
        System.out.println("Cash donation recorded: " + this.getDonorName() + " donated $" + this.getAmount() + " on " + donationDate);
    }

    @Override
    public String toString() {
        return "CashDonation [Donor Name=" + this.getDonorName() + ", Amount=" + this.getAmount() + ", Date=" + donationDate + "]";
    }
}
