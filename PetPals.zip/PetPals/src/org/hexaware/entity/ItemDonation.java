package org.hexaware.entity;

public class ItemDonation extends Donation {
    private String itemType; // Type of item donated (e.g., food, toys)

    // Constructor
    public ItemDonation(String donorName, double amount, String itemType) {
        super(donorName, amount);
        this.itemType = itemType;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }

    @Override
    public void recordDonation() {
        System.out.println("Item donation recorded: " + this.getDonorName() + " donated " + this.itemType + " worth $" + this.getAmount());
    }

    @Override
    public String toString() {
        return "ItemDonation [Donor Name=" + this.getDonorName() + ", Amount=" + this.getAmount() + ", Item Type=" + this.itemType + "]";
    }
}


//ItemDonation Class (Derived from Donation):
//Additional Attributes:
//• ItemType (string): The type of item donated (e.g., food, toys).
//Additional Methods:
//• Constructor to initialize ItemType.
//• Implementation of RecordDonation() to record an item donation.
