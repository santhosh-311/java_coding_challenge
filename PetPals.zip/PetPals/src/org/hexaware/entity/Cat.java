package org.hexaware.entity;

public class Cat extends Pet {
	private String catColor;

	public Cat(String name, int age, String breed, String catColor) {
		super(name, age, breed);
		setCatColor(catColor);
	}

	public String getCatColor() {
		return catColor;
	}

	public void setCatColor(String catColor) {
		this.catColor = catColor;
	}
	
	
}


//Cat Class (Inherits from Pet):
//Additional Attributes:
//• CatColor (string): The color of the cat.
//Additional Methods:
//• Constructor to initialize CatColor.
//• Getters and setters for CatColor.
