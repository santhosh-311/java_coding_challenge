package org.hexaware.entity;

import org.hexaware.exception.NullReferenceException;
import java.util.ArrayList;

public class PetShelter {
    // List to store available pets
    public ArrayList<Pet> availablePets;

    // Constructor to initialize the list
    public PetShelter() {
        setAvailablePets(new ArrayList<>());
    }

    // Method to add a pet to the shelter
    public void add(String name, int age, String breed) {
        // Call the ExceptionHandler to validate age
    	NullReferenceException.handlePetAgeException(age);
        
        // Create a new Pet object
        Pet pet = new Pet(name, age, breed);
        getAvailablePets().add(pet);
        System.out.println("Pet added: " + pet);
    }

    // Method to check if a pet is available
    public boolean contains(String name) {
        for (Pet pet : getAvailablePets()) {
            if (pet.getName().equals(name)) {
                return true;
            }
        }
        return false;
    }

    // Method to list available pets with null reference handling
    public void listAvailablePets() {
        if (getAvailablePets().isEmpty()) {
            System.out.println("No pets available for adoption.");
            return;
        }

        System.out.println("Available Pets:");
        for (Pet pet : getAvailablePets()) {
            // Use ExceptionHandler to validate properties
        	NullReferenceException.handleNullReferenceException(pet);
            System.out.println(pet); // Print pet details
        }
    }

	public ArrayList<Pet> getAvailablePets() {
		return availablePets;
	}

	public void setAvailablePets(ArrayList<Pet> availablePets) {
		this.availablePets = availablePets;
	}
}
