package org.hexaware.entity;

public class Dog extends Pet {
	private String dogBreed;

	public Dog(String name, int age, String breed) {
		super(name, age, breed);
		this.dogBreed=breed;
	}

	public String getDogBreed() {
		return dogBreed;
	}

	public void setDogBreed(String dogBreed) {
		this.dogBreed = dogBreed;
	}
	
	

}

//Dog Class (Inherits from Pet):
//Additional Attributes:
//• DogBreed (string): The specific breed of the dog.
//Additional Methods:
//• Constructor to initialize DogBreed.
//• Getters and setters for DogBreed.