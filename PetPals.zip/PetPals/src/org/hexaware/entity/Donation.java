package org.hexaware.entity;
import org.hexaware.exception.*;
public abstract class Donation {
	private String donorName;
	private double amount;
	private static final double MINIMUM_DONATION_AMOUNT = 10.00;
	public Donation(String donorName, double amount) {
		try {

            if (amount < MINIMUM_DONATION_AMOUNT) {
                throw new InsufficientFundsException("Donation amount must be at least $10.");
            }

            System.out.println("Thank you for your generous donation of $" + amount + "!");
        } catch (InsufficientFundsException e) {
            System.out.println("Error: " + e.getMessage());
        }
		this.setDonorName(donorName);
		this.setAmount(amount);
	}
	
	public abstract void recordDonation();

	public String getDonorName() {
		return donorName;
	}

	public void setDonorName(String donorName) {
		this.donorName = donorName;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
}