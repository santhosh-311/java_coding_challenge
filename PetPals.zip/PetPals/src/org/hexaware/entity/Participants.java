package org.hexaware.entity;

public class Participants extends IAdoptable {
    private String participantName;   // Name of the participant
    private String participantType;    // Type of participant (e.g., Adopter, Shelter)

    // Constructor
    public Participants(String participantName, String participantType) {
        this.participantName = participantName;
        this.participantType = participantType;
    }

    // Getters
    public String getParticipantName() {
        return participantName;
    }

    public String getParticipantType() {
        return participantType;
    }

    // Setters
    public void setParticipantName(String participantName) {
        this.participantName = participantName;
    }

    public void setParticipantType(String participantType) {
        this.participantType = participantType;
    }

    @Override
    public String toString() {
        return "Participant [Name=" + participantName + ", Type=" + participantType + "]";
    }

	@Override
	public void adopt() {
		
	}
}
