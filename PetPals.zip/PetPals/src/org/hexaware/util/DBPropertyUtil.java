package org.hexaware.util;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class DBPropertyUtil
{
	private static final String path = "db.properties";
    public static String getConnString()
    {
    String connectionString = null;
        Properties props = new Properties();
        try (InputStream inputStream = DBPropertyUtil.class.getResourceAsStream(path)) {
           
                props.load(inputStream);
                
                connectionString = props.getProperty("db.url")+"?user="+props.getProperty("db.user")+"&password="+props.getProperty("db.password");
                return connectionString;
            }
         catch (IOException e) {
            e.printStackTrace();
       
        }
        return connectionString;

    }
}
					
