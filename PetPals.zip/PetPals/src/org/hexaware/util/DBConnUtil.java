package org.hexaware.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnUtil
{
	static Connection con;

	public static Connection getConnection()
	{
		try {
			con = DriverManager.getConnection(DBPropertyUtil.getConnString());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
	
}
